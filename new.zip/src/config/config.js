const port = process.env.PORT || 9999
const database_url = process.env.Database_url || 'tron'


module.exports = {
    port,
    database_url,
}